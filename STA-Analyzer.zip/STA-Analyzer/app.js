/**
 * Copyright 2015 IBM Corp. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

'use strict';

var express = require('express'),
  app       = express(),
  bluemix   = require('./config/bluemix'),
  extend    = require('util')._extend,
  routes = require('./routes'),
  watson    = require('watson-developer-cloud');

	
	

// Bootstrap application settings
require('./config/express')(app);

var credentials = extend({
  version: 'v2',
  url: 'https://gateway.watsonplatform.net/tone-analyzer-experimental/api',
  username: '2ebd67aa-33bf-435b-8001-e60518c1feaa',//
  password: 'mG8WxO3a126x'//
}, bluemix.getServiceCreds('tone_analyzer'));


// Create the service wrapper
var toneAnalyzer = watson.tone_analyzer(credentials);

// render index page
app.post('/', function(req, res) {
	res.locals.text = req.body.text;
	res.render('index');
});

app.post('/tone', function(req, res, next) {
	//res.send('You sent the name "' + req.body.text+ '".');
  toneAnalyzer.tone(req.body, function(err, data) {
	  toneAnalyzer
    if (err)
      return next(err);
    else{
		return res.json(data);}
 });
});

app.get('/synonyms', function(req, res, next) {
  toneAnalyzer.synonym(req.query, function(err, data) {
    if (err)
      return next(err);
    else
      return res.json(data);
  });
});

// error-handler settings
require('./config/error-handler')(app);

var port = process.env.VCAP_APP_PORT || 3001;
app.listen(port);
console.log('listening at:', port);






/**
 * Module dependencies.
 *

var express = require('express')
  , routes = require('./routes')
  , user = require('./routes/user')
  , http = require('http')
  , path = require('path');

var app = express();

// all environments
app.set('port', process.env.PORT || 3000);
app.set('views', __dirname + '/views');
app.set('view engine', 'jade');
app.use(express.favicon());
app.use(express.logger('dev'));
app.use(express.bodyParser());
app.use(express.methodOverride());
app.use(app.router);
app.use(express.static(path.join(__dirname, 'public')));

// development only
if ('development' == app.get('env')) {
  app.use(express.errorHandler());
}

app.get('/', routes.index);
app.get('/users', user.list);

http.createServer(app).listen(app.get('port'), function(){
  console.log('Express server listening on port ' + app.get('port'));
});
*/