
/*
 * GET home page.
 */



exports.main = function(req, res){
  console.log("post is called");
 
  res.render('index', { title: 'Express' });
};