# client-side javascript
Build the browser application using [Browserify][browserify].  
```sh
  $ npm install
  $ npm run build
```

[browserify]: http://browserify.org/
